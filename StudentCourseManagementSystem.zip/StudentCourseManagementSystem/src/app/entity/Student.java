package app.entity;

import app.entity.base.BaseEntity;

import java.util.Objects;

public class Student extends BaseEntity<Integer> implements Comparable<Student>{

    private String studentName;
    private String studentEmail;
    private String studentDepartment;

    public Student(Integer id, String studentName, String studentEmail, String studentDepartment) {
        this.id = id;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentDepartment = studentDepartment;
    }


    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentDepartment() {
        return studentDepartment;
    }

    public void setStudentDepartment(String studentDepartment) {
        this.studentDepartment = studentDepartment;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + id +
                ", studentName='" + studentName + '\'' +
                ", studentEmail='" + studentEmail + '\'' +
                ", studentDepartment='" + studentDepartment + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Student student)) return false;
        return id == student.id;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public int compareTo(Student o) {
        return this.studentName.compareTo(o.getStudentName());
    }
}
