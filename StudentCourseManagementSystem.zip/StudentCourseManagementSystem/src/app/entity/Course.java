package app.entity;

import app.entity.base.BaseEntity;

import java.util.Objects;

public class Course extends BaseEntity<Integer> {

    private String courseName;
    private String courseDuration;
    private Long coursePrice;

    public Course(Integer id, String courseName, String courseDurating, Long coursePrice) {
        this.id = id;
        this.courseName = courseName;
        this.courseDuration = courseDurating;
        this.coursePrice = coursePrice;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseDuration() {
        return courseDuration;
    }

    public void setCourseDuration(String courseDuration) {
        this.courseDuration = courseDuration;
    }

    public Long getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(Long coursePrice) {
        this.coursePrice = coursePrice;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Course course)) return false;
        return id == course.id;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Course{" +
                "courseId=" + id +
                ", courseName='" + courseName + '\'' +
                ", courseDuration='" + courseDuration + '\'' +
                ", coursePrice=" + coursePrice +
                '}';
    }


}
