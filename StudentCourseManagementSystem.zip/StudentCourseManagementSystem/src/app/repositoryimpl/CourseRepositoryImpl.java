package app.repositoryimpl;

import app.entity.Course;
import app.repository.CourseRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CourseRepositoryImpl implements CourseRepository {

    private final List<Course> courseDB = new ArrayList<>();

    @Override
    public Course addCourse(Course course) {
        courseDB.add(course);
        return course;
    }

    @Override
    public Optional<Course> findCourseById(Integer id) {
        return courseDB.stream().filter(x -> x.getId() == id).findFirst();
    }

    @Override
    public List<Course> findAllCourses() {
        return courseDB;
    }

    @Override
    public Course updateCourse(Course updatedCourse) {
        int i = courseDB.indexOf(updatedCourse);
        courseDB.set(i, updatedCourse);
        return updatedCourse;
    }

    @Override
    public void deleteCourse(Course course) {
        courseDB.remove(course);
    }
}
