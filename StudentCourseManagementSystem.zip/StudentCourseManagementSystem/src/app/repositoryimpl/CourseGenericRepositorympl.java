package app.repositoryimpl;

import app.entity.Course;

import java.util.ListIterator;
import java.util.Optional;

public class CourseGenericRepositorympl extends GenericRepositoryImpl<Course, Integer>{

    public Optional<Course> findByName(String courseName){
        ListIterator<Course> courseListIterator = list.listIterator();
        while(courseListIterator.hasNext()){
            Course course = courseListIterator.next();
            if(course.getCourseName().equals(courseName)){
                return Optional.ofNullable(course);
            }
        }
        return Optional.empty();
    }
}
