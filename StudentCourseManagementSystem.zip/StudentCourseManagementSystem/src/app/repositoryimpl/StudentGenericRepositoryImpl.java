package app.repositoryimpl;

import app.entity.Student;

import java.util.ListIterator;
import java.util.Optional;

public class StudentGenericRepositoryImpl extends GenericRepositoryImpl<Student,Integer>{

    public Optional<Student> findByEmail(String email){
        ListIterator<Student> studentListIterator = list.listIterator();
        while(studentListIterator.hasNext()){
            Student student = studentListIterator.next();
            if(student.getStudentEmail().equals(email)){
                return Optional.ofNullable(student);
            }
        }
        return Optional.empty();
    }
}
