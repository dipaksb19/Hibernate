package app.repositoryimpl;

import app.entity.Student;
import app.repository.StudentRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StudentRepositoryImpl implements StudentRepository {
    private final List<Student> studentsDB = new ArrayList<>();


    @Override
    public Student addStudent(Student newStudent) {
        studentsDB.add(newStudent);
        return newStudent;
    }

    @Override
    public Optional<Student> findById(Integer id) {
        return  studentsDB.stream().filter((x) -> x.getId() == id).findFirst();
    }

    @Override
    public List<Student> findAll() {
        return studentsDB;
    }

    @Override
    public Student updateStudent(Student updatedStudent) {
        int i = studentsDB.indexOf(updatedStudent);
        return studentsDB.set(i,updatedStudent);
    }

    @Override
    public boolean deleteStudent(Student student) {
        return studentsDB.remove(student);
    }

}
