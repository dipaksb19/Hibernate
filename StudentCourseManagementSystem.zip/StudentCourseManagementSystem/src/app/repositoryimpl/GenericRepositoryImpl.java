package app.repositoryimpl;

import app.entity.base.BaseEntity;
import app.repository.GenericRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;

public abstract class GenericRepositoryImpl <T extends BaseEntity<ID>, ID> implements GenericRepository<T,ID> {

    protected final List<T> list = new ArrayList<>();

    @Override
    public T addData(T newData) {
        list.add(newData);
        return newData;
    }

    @Override
    public Optional<T> findById(ID id) {
        return  list.stream().filter(x -> x.getId().equals(id)).findFirst();
    }

    @Override
    public List<T> findAll() {
        return list;
    }

    @Override
    public T updateData(T updatedData) {
        int i = list.indexOf(updatedData);
        list.set(i, updatedData);
        return updatedData;
    }

    @Override
    public void deleteDataById(ID id) {
        ListIterator<T> listIterator = list.listIterator();
        while(listIterator.hasNext()){
            if(listIterator.next().getId().equals(id)){
                listIterator.remove();
            }
        }
    }
}
