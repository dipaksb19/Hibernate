package app.jdbcserviceimpl;

import app.entity.Course;
import app.exception.CourseAlreadyExistException;
import app.exception.CourseNotFoundException;
import app.exception.InvalidInputEnteredException;
import app.jdbcrepositoryimpl.CourseJDBCRepositoryImpl;
import app.repository.JDBCRepository;
import app.service.JDBCCourseService;
import app.jdbcserviceimpl.validation.CourseValidator;

import java.util.List;
import java.util.Optional;

public class JDBCCourseServiceImpl implements JDBCCourseService {

    JDBCRepository<Course,Integer> jdbcRepository = new CourseJDBCRepositoryImpl();

    @Override
    public Course findById(Integer id) {
        Optional<Course> existingCourse = jdbcRepository.findById(id);
        if(existingCourse.isEmpty()){
            throw new CourseNotFoundException("Course does not exist with id - " + id);
        }
        return existingCourse.get();
    }

    @Override
    public List<Course> findAll() {
        return jdbcRepository.findAll().stream()
                .sorted((x,y) -> Math.toIntExact(x.getCoursePrice() - y.getCoursePrice()))
                .toList();
    }

    @Override
    public void deleteById(Integer id) {
        Optional<Course> existingCourse = jdbcRepository.findById(id);
        if(existingCourse.isEmpty()){
            throw new CourseNotFoundException("Course does not exist with id - " + id);
        }
        jdbcRepository.deleteById(id);
    }

    @Override
    public void addCourse(Course course) {
        CourseValidator.validate(course);
        Optional<Course> existingCourse = jdbcRepository.findById(course.getId());
        if(existingCourse.isPresent()){
            throw new CourseAlreadyExistException("Course Already Exist with id - " + course.getId());
        }
        jdbcRepository.save(course);
    }

    @Override
    public void updateCourse(Course course) {
        Optional<Course> existingCourse = jdbcRepository.findById(course.getId());
        if(existingCourse.isEmpty()){
            throw new CourseNotFoundException("Course does not exist with id - " + course.getId());
        }
        jdbcRepository.update(course);
    }
}
