package app.jdbcserviceimpl;

import app.entity.Student;
import app.exception.InvalidInputEnteredException;
import app.exception.StudentAlreadyExistException;
import app.exception.StudentNotFoundException;
import app.jdbcrepositoryimpl.StudentJDBCRepositoryImpl;
import app.repository.JDBCRepository;
import app.service.JDBCStudentService;
import app.jdbcserviceimpl.validation.StudentValidator;

import java.util.List;
import java.util.Optional;

public class JDBCStudentServiceImpl implements JDBCStudentService{

    JDBCRepository<Student, Integer> jdbcRepository = new StudentJDBCRepositoryImpl();

    @Override
    public Student findById(Integer id) {
        Optional<Student> existingStudent = jdbcRepository.findById(id);
        if(existingStudent.isEmpty()){ // Checking if fetched object is empty or not
            throw new StudentNotFoundException("Student does not exist with id - " + id);
        }
        return existingStudent.get();
    }

    @Override
    public List<Student> findAll() {
        return jdbcRepository.findAll()
                .stream()
                .sorted() // sorting by comparable
                .toList();
    }

    @Override
    public void deleteById(Integer id) {
        Optional<Student> existingStudent = jdbcRepository.findById(id);
        if(existingStudent.isEmpty()){
            throw new StudentNotFoundException("Student does not exist with id - " + id);
        }
        jdbcRepository.deleteById(id);
    }

    @Override
    public void addStudent(Student student) {
        StudentValidator.validate(student);
        Optional<Student> existingStudent = jdbcRepository.findById(student.getId());
        if(existingStudent.isPresent()){ // checking already exist with same indexist or not
            throw new StudentAlreadyExistException("Student Already Exist with id - " + student.getId());
        }
        jdbcRepository.save(student);
    }

    @Override
    public void updateStudent(Student student) {
        Optional<Student> existingStudent = jdbcRepository.findById(student.getId());
        if(existingStudent.isEmpty()){ // checking for null  throwing exception
            throw new StudentNotFoundException("Student does not exist with id - " + student.getId());
        }
        jdbcRepository.update(student);
    }

}
