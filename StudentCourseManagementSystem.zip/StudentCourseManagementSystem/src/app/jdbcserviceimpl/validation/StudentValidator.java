package app.jdbcserviceimpl.validation;

import app.entity.Student;
import app.exception.InvalidInputEnteredException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentValidator {

    private static final String emailRegExpression = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    private static final Pattern emailPatteren = Pattern.compile(emailRegExpression);

    public static boolean isValidEmail(String email) {
        Matcher matcher = emailPatteren.matcher(email);
        return matcher.matches();
    }

    public static void validate(Student student){
        if(student.getId() <= 0){
            throw new InvalidInputEnteredException("Id");
        }else if(student.getStudentName() == null || student.getStudentName().isEmpty() || student.getStudentName().isBlank()){
            throw new InvalidInputEnteredException("Name");
        }else if(student.getStudentEmail() == null || student.getStudentEmail().isEmpty() || student.getStudentEmail().isBlank() || !isValidEmail(student.getStudentEmail())){
            throw new InvalidInputEnteredException("Email");
        }else if(student.getStudentDepartment() == null || student.getStudentDepartment().isEmpty() || student.getStudentDepartment().isBlank()){
            throw new InvalidInputEnteredException("Department");
        }

    }
}
