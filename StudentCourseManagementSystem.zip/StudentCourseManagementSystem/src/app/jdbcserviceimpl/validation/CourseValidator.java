package app.jdbcserviceimpl.validation;

import app.entity.Course;
import app.exception.InvalidInputEnteredException;

public class CourseValidator {

    public static void validate(Course course){
        if(course.getId() <= 0){
            throw new InvalidInputEnteredException("Id");
        }else if(course.getCourseName() == null || course.getCourseName().isEmpty() || course.getCourseName().isBlank()){
            throw new InvalidInputEnteredException("Name");
        }else if(course.getCourseDuration() == null || course.getCourseDuration().isEmpty() || course.getCourseDuration().isBlank()){
            throw new InvalidInputEnteredException("Duration");
        }else if(course.getCoursePrice() <= 0){
            throw new InvalidInputEnteredException("Course Price");
        }
    }
}
