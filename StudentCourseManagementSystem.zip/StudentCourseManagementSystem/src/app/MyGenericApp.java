package app;

import app.entity.Course;
import app.entity.Student;
import app.repositoryimpl.CourseGenericRepositorympl;
import app.repositoryimpl.StudentGenericRepositoryImpl;
import app.service.GenericService;
import app.serviceimpl.CourseGenericServiceImpl;
import app.serviceimpl.GenericServiceImpl;
import app.serviceimpl.StudentGenericServiceImpl;

import java.util.List;
import java.util.Scanner;

public class MyGenericApp {
    public static void main(String[] args) {


        System.out.println("\t\t----- Application -----");


        StudentGenericServiceImpl student = new StudentGenericServiceImpl(new StudentGenericRepositoryImpl());
        CourseGenericServiceImpl course = new CourseGenericServiceImpl(new CourseGenericRepositorympl());


        Scanner sc1 = new Scanner(System.in);
        System.out.println("Home --->");
        System.out.println("Enter 1 to start");
        System.out.println("Enter Here : ");
        int start = sc1.nextInt();

        while(start == 1){
            System.out.println("Select below option :");
            System.out.println("1. Go to Student \n2. Go to Course");
            System.out.println("Enter Here : ");
            int option = sc1.nextInt();

            if(option == 1){
                // student
                System.out.println("Student Section --->");
                while(start == 1){
                    System.out.println("\nSelect Option from below menu :");
                    System.out.println("0. Exit \n1. Register new Student\n2. Get Student\n3. Get All Available Students List\n4. Update Student\n5. Delete Student\n6. Find Student By Email");
                    System.out.println("Enter Option Here : ");
                    int studentOperation = sc1.nextInt();

                    switch (studentOperation){
                        case 1 :
                            // Register new Student
                            System.out.println("Enter Student Details : ");
                            System.out.println("Enter id : ");
                            int id = sc1.nextInt();
                            sc1.nextLine();
                            System.out.println("Enter Name : ");
                            String name = sc1.nextLine();
                            System.out.println("Enter Email :");
                            String email = sc1.nextLine();
                            System.out.println("Enter Department : ");
                            String department = sc1.nextLine();
                            System.out.println(student.addData(new Student(id,name,email,department)));
                            break;

                        case 2 :
                            // Find Student By-Id
                            System.out.println("Enter Student id : ");
                            int studentId = sc1.nextInt();
                            System.out.println(student.findById(studentId));
                            break;

                        case 3 :
                            // Find all available students
                            List<Student> list = student.findAll();
                            for(Student eachStudent : list){
                                System.out.println(eachStudent);
                            }
                            break;

                        case 4 :
                            // update existing student
                            System.out.println("Enter detail to Update Student : ");
                            System.out.println("Enter Existing Student's id : ");
                            int studentIdToUpdate = sc1.nextInt();
                            sc1.nextLine();
                            System.out.println("Enter Student Name : ");
                            String studentName = sc1.nextLine();
                            System.out.println("Enter Student Email : ");
                            String studentEmail = sc1.nextLine();
                            System.out.println("Enter Student Department : ");
                            String studentDepartment = sc1.nextLine();
                            System.out.println(student.updateData(new Student(studentIdToUpdate, studentName, studentEmail, studentDepartment)));
                            break;

                        case 5 :
                            // delete existing student
                            System.out.println("Enter Student id : ");
                            int studentIdToDelete = sc1.nextInt();
                            student.deleteDataById(studentIdToDelete);
                            break;

                        case 6 :
                            System.out.println("Enter Student Email : ");
                            String studEmail = sc1.next();
                            System.out.println(student.getByEmail(studEmail));
                            break;
                        default:
                            // exit from student section
                            start = 0;
                            System.out.println("Exited from student !");
                    }
                }
            }else if(option == 2){
                // course
                System.out.println("Course Section --->");
                while(start == 1){
                    System.out.println("Select Option from below menu :");
                    System.out.println("0. Exit \n1. Register new Course\n2. Get Course\n3. Get All Available Courses List\n4. Update Course\n5. Delete Course\n6. Find By Course Name");
                    System.out.println("Enter Option Here : ");
                    int courseOperation = sc1.nextInt();

                    switch(courseOperation){
                        case 1 :
                            // Add new course
                            System.out.println("Enter course details :");
                            System.out.println("Enter Id : ");
                            int id = sc1.nextInt();
                            sc1.nextLine();
                            System.out.println("Enter course name : ");
                            String name = sc1.nextLine();
                            System.out.println("Enter Duration : ");
                            String duration = sc1.nextLine();
                            System.out.println("Course Fees : ");
                            long fees = sc1.nextLong();
                            System.out.println(course.addData(new Course(id, name, duration, fees)));
                            break;

                        case 2 :
                            // Find course by id
                            System.out.println("Enter course id : ");
                            int courseId = sc1.nextInt();
                            System.out.println(course.findById(courseId));
                            break;

                        case 3 :
                            // find all available courses
                            List<Course> list= course.findAll();
                            for(Course eachCourse : list){
                                System.out.println(eachCourse);
                            }
                            break;

                        case 4 :
                            // Update existing course
                            System.out.println("Enter detail to Update Course : ");
                            System.out.println("Enter Existing Course id : ");
                            int existingCourseId = sc1.nextInt();
                            sc1.nextLine();
                            System.out.println("Enter Course Name : ");
                            String updatedCourseName = sc1.nextLine();
                            System.out.println("Enter Duration : ");
                            String updatedCourseDuration = sc1.nextLine();
                            System.out.println("Enter Course Fees : ");
                            long updatedCourseFees = sc1.nextLong();
                            System.out.println(course.updateData(new Course(existingCourseId, updatedCourseName, updatedCourseDuration, updatedCourseFees)));
                            break;

                        case 5 :
                            // Delete existing course
                            System.out.println("Enter Course Id : ");
                            int courseIdToDelete = sc1.nextInt();
                            course.deleteDataById(courseIdToDelete);
                            break;

                        case 6 :
                            System.out.println("Enter the Course name : ");
                            String existingCourseName = sc1.next();
                            System.out.println(course.getCourseByName(existingCourseName));
                            break;
                        default:
                            // exit from course section
                            start = 0;
                            System.out.println("Exited from Course !");
                    }
                }

            }else{
                System.out.println("Invalid Input Entered !");
            }

            System.out.println("Home --->");
            System.out.println("1. to continue \n2. to Stope");
            System.out.println("Enter Here : ");
            start = sc1.nextInt();
        }
        System.out.println("--- Application Stopped ---");



    }
}




















//        GenericService<Student> genericService1 = new GenericServiceImpl<>();
//        System.out.println(genericService1.addData(new Student(1,"Dipak","dbhide@gmail.com","computer")));
//        System.out.println(genericService1.addData(new Student(2,"Jayesh","jayesh@gmail.com","it")));
//        System.out.println(genericService1.findById(1));
//        System.out.println(genericService1.updateData(new Student(1,"Suraj","dbhide@gmail.com","computer")));
//        System.out.println(genericService1.deleteDataById(2));
//        System.out.println("All Objects : ");
//        System.out.println(genericService1.findAll());
//
//        GenericService<Course> genericService2 = new GenericServiceImpl<>();
//        System.out.println(genericService2.addData(new Course(1,"Java full stack","4 months",30000)));
//        System.out.println(genericService2.findById(1));
//        System.out.println(genericService2.updateData(new Course(1,"java","2 Months", 30000)));
//        System.out.println(genericService2.deleteDataById(1));
//        System.out.println("All Onbjects :");
//        System.out.println(genericService2.findAll());