package app.repository;

import java.util.List;
import java.util.Optional;

public interface JDBCRepository<T, ID> {

    Optional<T> findById(ID id);

    List<T> findAll();

    void deleteById(ID id);

    void save(T object);

    void update(T object);


}
