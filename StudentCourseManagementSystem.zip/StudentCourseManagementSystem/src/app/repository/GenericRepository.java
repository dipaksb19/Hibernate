package app.repository;

import java.util.List;
import java.util.Optional;

public interface GenericRepository<T,ID> {
    T addData(T newData);

    Optional<T> findById(ID id);

    List<T> findAll();

    T updateData(T updatedData);

    void deleteDataById(ID id);


}
