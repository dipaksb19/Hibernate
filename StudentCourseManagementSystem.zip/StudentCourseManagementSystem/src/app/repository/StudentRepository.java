package app.repository;

import app.entity.Student;

import java.util.List;
import java.util.Optional;

public interface StudentRepository {

    Student addStudent(Student newStudent);

    Optional<Student> findById(Integer id);

    List<Student> findAll();

    Student updateStudent(Student updatedStudent);

    boolean deleteStudent(Student student);

}
