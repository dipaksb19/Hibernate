package app.repository;

import app.entity.Course;

import java.util.List;
import java.util.Optional;

public interface CourseRepository {

    Course addCourse(Course course);

    Optional<Course> findCourseById(Integer id);

    List<Course> findAllCourses();

    Course updateCourse(Course updatedCourse);

    void deleteCourse(Course course);
}
