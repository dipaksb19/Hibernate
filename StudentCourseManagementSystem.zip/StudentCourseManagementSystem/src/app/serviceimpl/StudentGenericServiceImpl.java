package app.serviceimpl;

import app.entity.Course;
import app.entity.Student;
import app.exception.InvalidInputEnteredException;
import app.exception.ObjectNotFoundException;
import app.exception.StudentNotFoundException;
import app.repository.GenericRepository;
import app.repositoryimpl.GenericRepositoryImpl;
import app.repositoryimpl.StudentGenericRepositoryImpl;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentGenericServiceImpl extends GenericServiceImpl<Student,Integer>{

    StudentGenericRepositoryImpl genericRepository ;
    public StudentGenericServiceImpl(StudentGenericRepositoryImpl studentGenericRepository) {
        super(studentGenericRepository);
        this.genericRepository = studentGenericRepository;
    }

    private static final String emailRegExpression = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    private static final Pattern emailPatteren = Pattern.compile(emailRegExpression);

    public static boolean isValidEmail(String email) {
        Matcher matcher = emailPatteren.matcher(email);
        return matcher.matches();
    }
    @Override
    public void validation(Student student) {
        if(student.getId() <= 0){
           throw new InvalidInputEnteredException("Id");
        }else if(student.getStudentName() == null || student.getStudentName().isEmpty() || student.getStudentName().isBlank()){
            throw new InvalidInputEnteredException("Name");
        }else if(student.getStudentEmail() == null || student.getStudentEmail().isEmpty() || student.getStudentEmail().isBlank() || !isValidEmail(student.getStudentEmail())){
            throw new InvalidInputEnteredException("Email");
        }else if(student.getStudentDepartment() == null || student.getStudentDepartment().isEmpty() || student.getStudentDepartment().isBlank()){
            throw new InvalidInputEnteredException("Department");
        }

    }

    public Student getByEmail(String email) {
        Optional<Student> existingStudent = genericRepository.findByEmail(email);
        if(existingStudent.isEmpty()){
            throw new StudentNotFoundException("Student Not Found in Database");
        }
        return existingStudent.get();
    }
}
