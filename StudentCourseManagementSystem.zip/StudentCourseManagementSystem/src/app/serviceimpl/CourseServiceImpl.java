package app.serviceimpl;

import app.entity.Course;
import app.exception.CourseAlreadyExistException;
import app.exception.CourseNotFoundException;
import app.jdbcserviceimpl.validation.CourseValidator;
import app.repository.CourseRepository;
import app.repositoryimpl.CourseRepositoryImpl;
import app.service.CourseService;

import java.util.List;
import java.util.Optional;

public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepo = new CourseRepositoryImpl();

    @Override
    public Course addCourse(Course newCourse) {
        CourseValidator.validate(newCourse);
        Optional<Course> existingCourse = courseRepo.findCourseById(newCourse.getId());
        if(existingCourse.isPresent()){
            throw new CourseAlreadyExistException("Course Already Exist with id - " + newCourse.getId());
        }
       return courseRepo.addCourse(newCourse);
    }

    @Override
    public Course findById(Integer id) {
        Optional<Course> dbCourse = courseRepo.findCourseById(id);
        if(dbCourse.isEmpty()){
            throw new CourseNotFoundException("Course does not exist with id - " + id);
        }
        return dbCourse.get();
    }

    @Override
    public List<Course> findAllCourses() {
        return courseRepo.findAllCourses().stream().sorted((x,y) -> Math.toIntExact(x.getCoursePrice() - y.getCoursePrice())).toList();
    }

    @Override
    public Course updateCourse(Course updatedCourse) {
        Optional<Course> existingCourse = courseRepo.findCourseById(updatedCourse.getId());
        if(existingCourse.isEmpty()){
            throw new CourseNotFoundException("Course does not exist ! id - " + updatedCourse.getId());
        }
        existingCourse.get().setCourseName(updatedCourse.getCourseName());
        existingCourse.get().setCourseDuration(updatedCourse.getCourseDuration());
        existingCourse.get().setCoursePrice(updatedCourse.getCoursePrice());
        return courseRepo.updateCourse(existingCourse.get());
    }

    @Override
    public void deleteCourseById(Integer id) {
        Optional<Course> dbCourse = courseRepo.findCourseById(id);
        if(dbCourse.isEmpty()){
            throw new CourseNotFoundException("Course does not exist with id - " + id);
        }
        courseRepo.deleteCourse(dbCourse.get());
    }
}
