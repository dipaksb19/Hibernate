package app.serviceimpl;

import app.entity.Course;
import app.exception.CourseNotFoundException;
import app.exception.InvalidInputEnteredException;
import app.repositoryimpl.CourseGenericRepositorympl;
import app.repositoryimpl.GenericRepositoryImpl;
import app.repositoryimpl.StudentGenericRepositoryImpl;

import java.util.Optional;

public class CourseGenericServiceImpl extends GenericServiceImpl<Course,Integer>{

    CourseGenericRepositorympl genericRepository;
    public CourseGenericServiceImpl(CourseGenericRepositorympl courseGenericRepository) {
        super(courseGenericRepository);
        this.genericRepository = courseGenericRepository;
    }


    @Override
    public void validation(Course course) {
        if(course.getId() <= 0){
            throw new InvalidInputEnteredException("Id");
        }else if(course.getCourseName() == null || course.getCourseName().isEmpty() || course.getCourseName().isBlank()){
            throw new InvalidInputEnteredException("Name");
        }else if(course.getCourseDuration() == null || course.getCourseDuration().isEmpty() || course.getCourseDuration().isBlank()){
            throw new InvalidInputEnteredException("Duration");
        }else if(course.getCoursePrice() <= 0){
            throw new InvalidInputEnteredException("Course Price");
        }
    }

    public Course getCourseByName(String courseName){
        Optional<Course> existingCourse = genericRepository.findByName(courseName);
        if(existingCourse.isEmpty()){
            throw new CourseNotFoundException("Course not Found in Database");
        }
        return existingCourse.get();
    }


}
