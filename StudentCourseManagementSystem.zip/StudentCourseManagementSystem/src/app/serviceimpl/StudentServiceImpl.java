package app.serviceimpl;

import app.entity.Student;
import app.exception.InvalidInputEnteredException;
import app.exception.StudentAlreadyExistException;
import app.exception.StudentNotFoundException;
import app.repository.StudentRepository;
import app.repositoryimpl.StudentRepositoryImpl;
import app.service.StudentService;
import app.jdbcserviceimpl.validation.StudentValidator;

import java.util.List;
import java.util.Optional;

public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepo = new StudentRepositoryImpl();

    @Override
    public Student addStudent(Student newStudent) {
        StudentValidator.validate(newStudent);
        Optional<Student> existingStudent = studentRepo.findById(newStudent.getId());
        if(existingStudent.isPresent()){
            throw new StudentAlreadyExistException("Student already exist with id - " + newStudent.getId());
        }
        return studentRepo.addStudent(newStudent);
    }

    @Override
    public Student findById(Integer id) {
        Optional<Student> dbStudent = studentRepo.findById(id);
        if(dbStudent.isEmpty()){
            throw new StudentNotFoundException("Student does not exist with id - " + id);
        }
        return dbStudent.get();
    }

    @Override
    public List<Student> findAll() {
        return studentRepo.findAll().stream().sorted((x,y) -> x.getStudentName().charAt(0) - y.getStudentName().charAt(0)).toList();
    }

    @Override
    public Student updateStudent(Student updatedStudent) {
        Optional<Student> existingStudent = studentRepo.findById(updatedStudent.getId());
        if(existingStudent.isEmpty()){
            throw new StudentNotFoundException("Student does not exist with id - " + updatedStudent.getId());
        }
            existingStudent.get().setStudentName(updatedStudent.getStudentName());
            existingStudent.get().setStudentEmail(updatedStudent.getStudentEmail());
            existingStudent.get().setStudentDepartment(updatedStudent.getStudentDepartment());
            return studentRepo.updateStudent(existingStudent.get());
    }

    @Override
    public void deleteById(Integer id) {
        Optional<Student> student = studentRepo.findById(id);
        if(student.isEmpty()){
            throw new StudentNotFoundException("Student does not exist id - " + id);
        }
        studentRepo.deleteStudent(student.get());
    }
}
