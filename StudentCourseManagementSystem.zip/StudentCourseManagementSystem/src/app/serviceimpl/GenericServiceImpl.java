package app.serviceimpl;

import app.entity.Course;
import app.entity.base.BaseEntity;
import app.exception.InvalidInputEnteredException;
import app.exception.ObjectAlreadyExistException;
import app.exception.ObjectNotFoundException;
import app.repository.GenericRepository;
import app.repositoryimpl.GenericRepositoryImpl;
import app.service.GenericService;

import java.util.List;
import java.util.Optional;

public abstract class GenericServiceImpl<T extends BaseEntity<ID>, ID> implements GenericService<T,ID> {

    public abstract void validation(T objcet);

    GenericRepository<T,ID> genericRepository;

    public GenericServiceImpl(GenericRepository<T, ID> genericRepository) {
        this.genericRepository = genericRepository;
    }

    @Override
    public T addData(T newData) {
        validation(newData);
        Optional<T> existingObject = genericRepository.findById(newData.getId());
        if(existingObject.isPresent()){
            throw new ObjectAlreadyExistException("Object already exist with id - " + newData.getId());
        }
            return genericRepository.addData(newData);
    }

    @Override
    public T findById(ID id) {
        Optional<T> existingObject = genericRepository.findById(id);
        if(existingObject.isEmpty()){
            throw new ObjectNotFoundException("Object does not exist with id - " + id);
        }
        return existingObject.get();
    }

    @Override
    public List<T> findAll() {
        return genericRepository.findAll();
    }

    @Override
    public T updateData(T updatedData) {
        Optional<T> existingData = genericRepository.findById(updatedData.getId());
        if(existingData.isEmpty()){
            throw new ObjectNotFoundException("Object does not exist with id - " + updatedData.getId());
        }
        return genericRepository.updateData(updatedData);
    }

    @Override
    public void deleteDataById(ID id) {
        Optional<T> existingData = genericRepository.findById(id);
        if(existingData.isEmpty()){
            throw new ObjectNotFoundException("Object does not exist with id - " + id);
        }
        genericRepository.deleteDataById(id);
    }

}
