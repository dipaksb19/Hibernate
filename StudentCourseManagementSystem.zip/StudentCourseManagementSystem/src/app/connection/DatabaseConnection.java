package app.connection;

import java.sql.*;

public class DatabaseConnection {

    private static Connection connection;

    private static final String url = "jdbc:postgresql://172.16.1.195:5331/dbdemo";
    private static final String userName = "dbuser";
    private static final String password = "yF2awnXt";

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(url, userName, password);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return connection;
    }
}























/*


public class DatabaseConnection {
    public static void main(String[] args) {
        String url = "jdbc:postgresql://172.16.1.195:5331/dbdemo";
        String userName = "dbuser";
        String password = "yF2awnXt";

        String query = "select * from student";

        try (Connection conn = DriverManager.getConnection(url, userName, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                System.out.print(rs.getInt(1) + " ");
                System.out.print(rs.getString(2) + " ");
                System.out.print(rs.getString(3) + " ");
                System.out.print(rs.getString(4) + " ");
                System.out.println();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

*/