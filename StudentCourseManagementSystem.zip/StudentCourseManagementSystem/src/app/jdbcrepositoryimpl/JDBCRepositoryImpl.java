package app.jdbcrepositoryimpl;

import app.repository.JDBCRepository;
import app.connection.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public abstract class JDBCRepositoryImpl<T, ID> implements JDBCRepository<T, ID> {

    protected abstract String getTableName();

    protected abstract T objectMapper(ResultSet rs) throws SQLException;


    @Override
    public Optional<T> findById(ID id) {
        String query = "select * from " + getTableName() + " where id = ?";
        try(Connection connection = DatabaseConnection.getConnection()){
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setObject(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                return Optional.ofNullable(objectMapper(resultSet));
            }
        }catch(SQLException e){
            throw new RuntimeException();
        }
        return Optional.empty();
    }

    @Override
    public List<T> findAll() {
        String query = "select * from " + getTableName() + " ;";
        try(Connection connection = DatabaseConnection.getConnection()){
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<T> list = new ArrayList<>();
            while(resultSet.next()){
                T data = objectMapper(resultSet);
                list.add(data);
            }
            return list;
        }catch(SQLException e){
            throw new RuntimeException();
        }
    }

    @Override
    public void deleteById(ID id) {
        String query = "delete from " + getTableName() + " where id = ?";
        try(Connection connection = DatabaseConnection.getConnection()){
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setObject(1, id);
            preparedStatement.execute();
        }catch(SQLException e){
            throw new RuntimeException();
        }
    }


}
