package app.jdbcrepositoryimpl;

import app.connection.DatabaseConnection;
import app.entity.Course;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CourseJDBCRepositoryImpl extends JDBCRepositoryImpl<Course,Integer> {

    @Override
    protected String getTableName() {
        return "course";
    }

    @Override
    protected Course objectMapper(ResultSet resultSet) throws SQLException {
        return new Course(resultSet.getInt(1),resultSet.getString(2),resultSet.getString(3),resultSet.getLong(4));
    }

    @Override
    public void save(Course object) {
        String query = "insert into " + getTableName() + " values (?,?,?,?);";
        try (Connection connection = DatabaseConnection.getConnection()){
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setObject(1,object.getId());
            preparedStatement.setObject(2,object.getCourseName());
            preparedStatement.setObject(3,object.getCourseDuration());
            preparedStatement.setObject(4,object.getCoursePrice());
            preparedStatement.execute();
        }catch(SQLException e){
            throw new RuntimeException();
        }
    }

    @Override
    public void update(Course object) {
        String query = "update " + getTableName() + " set name = ?, duration = ?, price = ? where id = ?";
        try(Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setObject(1,object.getCourseName());
            preparedStatement.setObject(2,object.getCourseDuration());
            preparedStatement.setObject(3,object.getCoursePrice());
            preparedStatement.setObject(4,object.getId());
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            throw new RuntimeException();
        }
    }
}
