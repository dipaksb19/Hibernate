package app.jdbcrepositoryimpl;

import app.connection.DatabaseConnection;
import app.entity.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class  StudentJDBCRepositoryImpl extends JDBCRepositoryImpl<Student, Integer> {

    @Override
    protected String getTableName() {
        return "student";
    }

    @Override
    protected Student objectMapper(ResultSet resultSet) throws SQLException {
        return new Student(resultSet.getInt(1),resultSet.getString(2),resultSet.getString(3),resultSet.getString(4));
    }

    @Override
    public void save(Student object) {
        String query = "insert into " + getTableName() + " values (?,?,?,?);";
        try (Connection connection = DatabaseConnection.getConnection()){
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setObject(1,object.getId());
            preparedStatement.setObject(2,object.getStudentName());
            preparedStatement.setObject(3,object.getStudentEmail());
            preparedStatement.setObject(4,object.getStudentDepartment());
            preparedStatement.execute();
        }catch(SQLException e){
            throw new RuntimeException();
        }
    }

    @Override
    public void update(Student object) {
        String query = "update " + getTableName() + " set name = ?, email = ?, department = ? where id = ?";
        try(Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setObject(1,object.getStudentName());
            preparedStatement.setObject(2,object.getStudentEmail());
            preparedStatement.setObject(3,object.getStudentDepartment());
            preparedStatement.setObject(4,object.getId());
            preparedStatement.executeUpdate();
        }catch (SQLException e){
            throw new RuntimeException();
        }
    }

}
