package app.service;

import app.entity.Student;

import java.util.List;

public interface JDBCStudentService {
    Student findById(Integer id);

    List<Student> findAll();

    void deleteById(Integer id);

    void addStudent(Student student);

    void updateStudent(Student student);
}
