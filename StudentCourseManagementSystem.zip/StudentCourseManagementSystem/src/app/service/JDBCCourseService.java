package app.service;

import app.entity.Course;

import java.util.List;

public interface JDBCCourseService {

    Course findById(Integer id);

    List<Course> findAll();

    void deleteById(Integer id);

    void addCourse(Course course);

    void updateCourse(Course course);
}
