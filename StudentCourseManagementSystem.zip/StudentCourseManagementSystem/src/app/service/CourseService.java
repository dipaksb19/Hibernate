package app.service;

import app.entity.Course;

import java.util.List;

public interface CourseService {

    Course addCourse(Course newCourse);

    Course findById(Integer id);

    List<Course> findAllCourses();

    Course updateCourse(Course updatedCourse);

    void deleteCourseById(Integer id);
}
