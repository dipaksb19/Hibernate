package app.service;

import app.entity.Student;

import java.util.List;

public interface StudentService {

    Student addStudent(Student newStudent);

    Student findById(Integer id);

    List<Student> findAll();

    Student updateStudent(Student updatedStudent);

    void deleteById(Integer id);
}
