package app.service;

import java.util.List;

public interface GenericService<T,ID> {
    T addData(T newData);

    T findById(ID id);

    List<T> findAll();

    T updateData(T updatedData);

    void deleteDataById(ID id);
}
