package com.scm.repository;

import com.scm.entity.Student;

import java.util.List;
import java.util.Optional;

public interface StudentRepository {

    Optional<Student> findById(Integer id);

    List<Student> findAll();

    Optional<Student> findByEmail(String email);

    Student save(Student newStudent);

    Student update(Student updatedStudent);

    void remove(Student student);

}
