package com.scm.serviceimpl;

import com.scm.entity.Student;
import com.scm.exception.InvalidInputEnteredException;
import com.scm.exception.StudentAlreadyExistException;
import com.scm.exception.StudentDoesNotExistException;
import com.scm.repository.StudentRepository;
import com.scm.repositoryimpl.StudentRepositoryImpl;
import com.scm.service.StudentService;
import com.scm.serviceimpl.validate.StudentValidator;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class StudentServiceImpl implements StudentService {

    private StudentRepository studentRepository = new StudentRepositoryImpl();

    @Override
    public Student getById(Integer studentId) {
        Optional<Student> databaseStudent = studentRepository.findById(studentId);
        if(databaseStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student does not exist with id - " + studentId);
        }
        return databaseStudent.get();
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> allStudents = studentRepository.findAll()
                .stream()
                .sorted(Comparator.comparing(Student::getStudentName))
                .toList();
        return allStudents;
    }

    @Override
    public Student getByEmail(String studentEmail) {
        if(!StudentValidator.isValidEmail(studentEmail)){
            throw new InvalidInputEnteredException("Email");
        }
        Optional<Student> existingStudent = studentRepository.findByEmail(studentEmail);
        if(existingStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student does not exist with email - " + studentEmail);
        }
        return existingStudent.get();
    }

    @Override
    public Student registerNewStudent(Student newStudent) {
        StudentValidator.validate(newStudent); // feilds validation and email validation
        // for new student id will not be there so no need to check id
        Optional<Student> existByEmail = studentRepository.findByEmail(newStudent.getStudentEmail());
        if(existByEmail.isPresent()){ // checking email already exist or not
            throw new StudentAlreadyExistException("Student already exist by email - " + newStudent.getStudentEmail());
        }
        return studentRepository.save(newStudent);
    }

    @Override
    public Student updateStudent(Student updatedStudent) {
        if(!StudentValidator.isValidEmail(updatedStudent.getStudentEmail())){
            throw new InvalidInputEnteredException("Email");
        }
        Optional<Student> existingStudent = studentRepository.findById(updatedStudent.getId());
        if(existingStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student does not exist with id - " + updatedStudent.getId());
        }
        existingStudent.get().setStudentName(updatedStudent.getStudentName());
        existingStudent.get().setStudentEmail(updatedStudent.getStudentEmail());
        existingStudent.get().setStudentDepartment(updatedStudent.getStudentDepartment());
        return studentRepository.update(existingStudent.get());
    }

    @Override
    public void removeStudent(Integer studentId) {
        Optional<Student> existingStudent = studentRepository.findById(studentId);
        if(existingStudent.isEmpty()){
            throw new StudentDoesNotExistException("Student does not exist with id - " + studentId);
        }
        studentRepository.remove(existingStudent.get());
    }

}
