package com.scm.serviceimpl;

import com.scm.service.CourseService;

public class CourseServiceImpl implements CourseService {
}
