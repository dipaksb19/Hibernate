package com.scm;

import com.scm.entity.Course;
import com.scm.entity.Student;
import com.scm.repositoryimpl.StudentRepositoryImpl;
import com.scm.service.CourseService;
import com.scm.service.StudentService;
import com.scm.serviceimpl.CourseServiceImpl;
import com.scm.serviceimpl.StudentServiceImpl;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.List;
import java.util.Scanner;

public class MyApp {
    public static void main(String[] args) {

        StudentService student = new StudentServiceImpl();
        CourseService course = new CourseServiceImpl();

        Scanner sc = new Scanner(System.in);
        System.out.println("\t\t----- Student Course Management System -----");
        System.out.println("Home --->");
        System.out.println("Enter 1 to start");
        System.out.println("Enter Here : ");
        int start = sc.nextInt();

        while(start == 1){

            System.out.println("Select below option :");
            System.out.println("1. Go to Student \n2. Go to Course");
            System.out.println("Enter Here : ");
            int option = sc.nextInt();

            if(option == 1){
                // student
                System.out.println("Student Section --->");
                while(start == 1){
                    System.out.println("\nSelect Option from below menu :");
                    System.out.println("0. Exit \n1. Register new Student\n2. Get Student By Id\n3. Get Student By Email\n4. Get All Available Students List\n5. Update Student\n6. Delete Student");
                    System.out.println("Enter Option Here : ");
                    int studentOperation = sc.nextInt();

                    switch (studentOperation){
                        case 1 :
                            // Register New Student
                            System.out.println("Enter Student Details : ");
                            System.out.println("Enter Name : ");
                            String name = sc.next();
                            sc.nextLine();
                            System.out.println("Enter Email :");
                            String email = sc.nextLine();
                            System.out.println("Enter Department : ");
                            String department = sc.nextLine();
                            System.out.println(student.registerNewStudent(new Student(name,email,department)));
                            break;

                        case 2 :
                            // Find Student By Id
                            System.out.println("Enter Student id : ");
                            int studentId = sc.nextInt();
                            System.out.println(student.getById(studentId));
                            break;

                        case 3 :
                            // Find Student by email
                            System.out.println("Enter Student Email : ");
                            String studentEmail = sc.next();
                            System.out.println(student.getByEmail(studentEmail));
                            break;
                        case 4 :
                            // Find All Students Available in Database
                            List<Student> allStudents = student.getAllStudents();
                            for(Student eachStudent : allStudents){
                                System.out.println(eachStudent);
                            }
                            break;

                        case 5 :
                            // Update Student
                            System.out.println("Enter detail to Update Student : ");
                            System.out.println("Enter Existing Student's id : ");
                            int studentIdToUpdate = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Updated Student Name : ");
                            String studentName = sc.nextLine();
                            System.out.println("Enter Updated Student Email : ");
                            String studentUpdatedEmail = sc.nextLine();
                            System.out.println("Enter Updated Student Department : ");
                            String studentDepartment = sc.nextLine();
                            System.out.println(student.updateStudent(new Student(studentIdToUpdate, studentName, studentUpdatedEmail, studentDepartment)));
                            break;

                        case 6 :
                            // Delete Student By Id
                            System.out.println("Enter Student id : ");
                            int studentIdToDelete = sc.nextInt();
                            student.removeStudent(studentIdToDelete);
                            break;

                        default:
                            // Exit from student section
                            start = 0;
                            System.out.println("Exited from student !");
                    }
                }
            }else if(option == 2){
                // course
                System.out.println("Course Section --->");
                while(start == 1){
                    System.out.println("Select Option from below menu :");
                    System.out.println("0. Exit \n1. Register new Course\n2. Get Course\n3. Get All Available Courses List\n4. Update Course\n5. Delete Course");
                    System.out.println("Enter Option Here : ");
                    int courseOperation = sc.nextInt();

                    switch(courseOperation){
                        case 1 :
                            // Register for new course
                            System.out.println("Enter course details :");
                            System.out.println("Enter Id : ");
                            int id = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter course name : ");
                            String name = sc.nextLine();
                            System.out.println("Enter Duration : ");
                            String duration = sc.nextLine();
                            System.out.println("Course Fees : ");
                            long fees = sc.nextLong();
            //                System.out.println(course.addCourse(new Course(id, name, duration, fees)));
                            break;

                        case 2 :
                            // Find course by id
                            System.out.println("Enter course id : ");
                            int courseId = sc.nextInt();
             //               System.out.println(course.findById(courseId));
                            break;

                        case 3 :
                            // find all courses
//                            List<Course> allCourses = course.findAllCourses();
//                            for(Course eachCourse : allCourses){
//                                System.out.println(eachCourse);
//                            }
                            break;

                        case 4 :
                            // update course
                            System.out.println("Enter detail to Update Course :");
                            System.out.println("Enter Existing Course id : ");
                            int existingCourseId = sc.nextInt();
                            sc.nextLine();
                            System.out.println("Enter Updated Course Name : ");
                            String updatedCourseName = sc.nextLine();
                            System.out.println("Enter Updated Duration : ");
                            String updatedCourseDuration = sc.nextLine();
                            System.out.println("Enter Updated Course Fees : ");
                            long updatedCourseFees = sc.nextLong();
                        //    System.out.println(course.updateCourse(new Course(existingCourseId, updatedCourseName, updatedCourseDuration, updatedCourseFees)));
                            break;

                        case 5 :
                            // delete course
                            System.out.println("Enter Course Id : ");
                            int courseIdToDelete = sc.nextInt();
                       //     course.deleteCourseById(courseIdToDelete);
                            break;

                        default:
                            // default to exit from course section
                            start = 0;
                            System.out.println("Exited from Course !");

                    }
                }

            }else{
                System.out.println("Invalid Input Entered !");
            }

            System.out.println("Home --->");
            System.out.println("1. to continue \n2. to Stope");
            System.out.println("Enter Here : ");
            start = sc.nextInt();
        }
        System.out.println("--- Application Stopped ---");

    }
}


































//StudentRepositoryImpl obj = new StudentRepositoryImpl();
//
//        System.out.println(obj.findAll());
//        System.out.println(obj.save(new Student("Dipak Santosh Bhide","dipak.sb@gmail.com","comp")));
// System.out.println(obj.findById(1120));
//  System.out.println(obj.update(new Student(1120,"Dipak Santosh Bhide","dipak.sb@gmail.com","comp")));
//obj.remove(new Student(1121,"Dipak Santosh Bhide","dipak.sb@gmail.com","comp"));
//    System.out.println(obj.findByEmail("swaaj@gmail.com"));
//
//        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("StudentCourseManagement");
//        EntityManager entityManager = entityManagerFactory.createEntityManager();
//        entityManager.getTransaction().begin();
//        Student student = new Student("vishal","v@gmail.com","arts");
//        entityManager.persist(student);
//        Student student2 = new Student("swaraj","swaraj@gmail.com","science");
//        entityManager.persist(student2);
//        entityManager.getTransaction().commit();
//        entityManager.close();

//        entityManager.getTransaction().begin();
//        Course course = new Course("Physics","4 months",20000L);
//        entityManager.persist(course);
//        entityManager.getTransaction().commit();
//        entityManager.close();

