package com.scm.entitymanager;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class EntityManagerUtilityClass {

    private static EntityManagerFactory entityManagerFactory;

    private EntityManagerUtilityClass(){
    }

    public static EntityManagerFactory getEntityManagerFactoryInstance(){
        if(entityManagerFactory == null || !entityManagerFactory.isOpen()){
            entityManagerFactory = Persistence.createEntityManagerFactory("StudentCourseManagement");
        }
        return entityManagerFactory;
    }

    public static void closeEntityManagerFactory(){
        if(entityManagerFactory.isOpen() || entityManagerFactory != null){
            entityManagerFactory.close();
        }
    }
}

























