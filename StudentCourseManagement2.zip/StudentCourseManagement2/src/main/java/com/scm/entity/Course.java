package com.scm.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "course", schema = "institute")
@SequenceGenerator(name = "entity_sequence_generation", sequenceName = "scms_id_generator", allocationSize = 1)
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "entity_sequence_generation")
    private Integer id;
    @Column(name = "name", nullable = false, unique = true)
    private String courseName;
    @Column(name = "duration", nullable = false)
    private String courseDuration;
    @Column(name = "price", nullable = false)
    private Long coursePrice;

    public Course(String courseName, String courseDuration, Long coursePrice) {
        this.courseName = courseName;
        this.courseDuration = courseDuration;
        this.coursePrice = coursePrice;
    }

    public Course() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer courseId) {
        this.id = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseDuration() {
        return courseDuration;
    }

    public void setCourseDuration(String courseDuration) {
        this.courseDuration = courseDuration;
    }

    public Long getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(Long coursePrice) {
        this.coursePrice = coursePrice;
    }

    @Override
    public String toString() {
        return "Course{" +
                "courseId=" + id +
                ", courseName='" + courseName + '\'' +
                ", courseDuration='" + courseDuration + '\'' +
                ", coursePrice='" + coursePrice + '\'' +
                '}';
    }
}
