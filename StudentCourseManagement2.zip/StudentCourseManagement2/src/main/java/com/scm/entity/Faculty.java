package com.scm.entity;

import jakarta.persistence.Entity;


public class Faculty {
}
