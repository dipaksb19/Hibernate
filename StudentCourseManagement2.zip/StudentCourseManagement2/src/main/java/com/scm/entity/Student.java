package com.scm.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "student", schema = "institute")
@SequenceGenerator(name = "entity_sequence_generation", sequenceName = "scms_id_generator", allocationSize = 1)
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "entity_sequence_generation")
    private Integer id;
    @Column(name ="name", nullable = false)
    private String studentName;
    @Column(name ="email", nullable = false, unique = true)
    private String studentEmail;
    @Column(name = "department", nullable = false)
    private String studentDepartment;

    public Student(String studentName, String studentEmail, String studentDepartment) {
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentDepartment = studentDepartment;
    }

    public Student(Integer id, String studentName, String studentEmail, String studentDepartment) {
        this.id = id;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.studentDepartment = studentDepartment;
    }

    public Student() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer studentId) {
        this.id = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentDepartment() {
        return studentDepartment;
    }

    public void setStudentDepartment(String studentDepartment) {
        this.studentDepartment = studentDepartment;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + id +
                ", studentName='" + studentName + '\'' +
                ", studentEmail='" + studentEmail + '\'' +
                ", studentDepartment='" + studentDepartment + '\'' +
                '}';
    }
}
