package com.scm.service;

public interface CourseService {
}
