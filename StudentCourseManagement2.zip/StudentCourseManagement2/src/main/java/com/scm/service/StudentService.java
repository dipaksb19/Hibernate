package com.scm.service;

import com.scm.entity.Student;

import java.util.List;

public interface StudentService {
    Student getById(Integer studentId);

    List<Student> getAllStudents();

    Student getByEmail(String studentEmail);

    Student registerNewStudent(Student newStudent);

    Student updateStudent(Student updatedStudent);

    void removeStudent(Integer studentId);


}
