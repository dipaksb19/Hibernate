package com.scm.repositoryimpl;

import com.scm.entity.Student;
import com.scm.entitymanager.EntityManagerUtilityClass;
import com.scm.repository.StudentRepository;
import jakarta.persistence.*;

import java.util.List;
import java.util.Optional;
public class StudentRepositoryImpl implements StudentRepository {

    private final EntityManagerFactory entityManagerFactory = EntityManagerUtilityClass.getEntityManagerFactoryInstance();
    private final EntityManager entityManager = entityManagerFactory.createEntityManager();
    private EntityTransaction transaction = entityManager.getTransaction();

    void closeEntityManager(){
        entityManager.close();
    }


    @Override
    public Optional<Student> findById(Integer id) {
        Optional<Student> student = Optional.ofNullable(entityManager.find(Student.class, id));
        return student;
    }

    @Override
    public List<Student> findAll() {
        TypedQuery<Student> allStudents = entityManager.createQuery("select e from Student e", Student.class);
        return allStudents.getResultList();
    }

    @Override
    public Optional<Student> findByEmail(String email) {  // Q. is it valid to handle exception in this way or not ?
        try{
            TypedQuery<Student> studentByEmail = entityManager.createQuery("select e from Student e where e.studentEmail =: email", Student.class);
            studentByEmail.setParameter("email",email);
            return Optional.ofNullable(studentByEmail.getSingleResult());
        }catch (NoResultException e){
            return Optional.empty();
        }
    }

    @Override
    public Student save(Student newStudent) {
       // try{
            transaction.begin();
            entityManager.persist(newStudent);
            transaction.commit();
            return newStudent;
//        }catch (PersistenceException e){
//            closeEntityManager();
//            throw new RuntimeException("Database Error During save", e);
//        }
    }

    @Override
    public Student update(Student updatedStudent) {
        transaction.begin();
        Student dbStudent = entityManager.merge(updatedStudent);
        transaction.commit();
        return dbStudent;
    }

    @Override
    public void remove(Student student) {
        //Optional<Student> byId = findById(studentToDelete.getId());
        transaction.begin();
        entityManager.remove(student);
        transaction.commit();
    }

}
