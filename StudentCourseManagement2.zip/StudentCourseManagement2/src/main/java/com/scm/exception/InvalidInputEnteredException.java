package com.scm.exception;

public class InvalidInputEnteredException extends RuntimeException{
    public InvalidInputEnteredException(String msg) {
        super("Invalid Input Entered : " + msg);
    }
}
