package com.scm.exception;

public class StudentDoesNotExistException  extends RuntimeException{
    public StudentDoesNotExistException(String message) {
        super(message);
    }
}
