package com.jbk;

import java.util.List;
import java.util.Scanner;

import com.jbk.entity.Product;
import com.jbk.operation.Operation;
import com.jbk.utility.UserData;

public class Test {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int choise;
		boolean wantToContinue = true;
		
		do {
			System.out.println("Press 1 for Add Product");
			System.out.println("Press 2 for delete Product by ID");
			System.out.println("Press 3 for get Product by ID");
			System.out.println("Press 4 for Update Product");
			System.out.println("Press 5 to get all Product");
			System.out.println("Press 6 to get all Products by Order");
			System.out.println("Press 7 to get limited Products");
			System.out.println("Press 8 to get limited Products in order");
			System.out.println("Press 9 to get book by name");
			System.out.println("Press 10 to get products by ids");
			System.out.println("Press 11 to get products between ids");
			System.out.println("Press 12 to get products count");
			System.out.println("Press 13 to get minimum price product");
			System.out.println("Press 14 to get maximum price product");
			System.out.println("Press 15 to get Product of mfgDate or Qty");
			// Queries SQL vs HQL
			System.out.println("Press 16 for Query Example 1");
			System.out.println("Press 17 for Query Example 2");
			System.out.println("Press 18 for Query Example 3");
			System.out.println("Press 0 to Exit");
			
			Operation operation = new Operation();
			choise = scanner.nextInt();
			
			 
			switch(choise) {
			case 0:
				wantToContinue = false;
				break;
			case 1:{
				//System.out.println("Add Product");
				//Product product = new Product(2,"Book",100,10,"2030-06-06",null);
				Product product = UserData.getProductInfoFromUser();
				String msg = operation.addProduct(product);
				System.out.println(msg);
				break;
			}
			case 2:{
				System.out.println("Enter Product Id :");
				int productId = scanner.nextInt();
				String msg = operation.deleteProduct(productId);
				System.out.println(msg);
				break;
			}
			case 3:{
				System.out.println("Enter Product Id :");
				int productId = scanner.nextInt();
				Object msg = operation.getProductById(productId);
				System.out.println(msg);
				break;
			}
			case 4:{
				System.out.println("Enter Product id :");
				int id = scanner.nextInt();
				Product product = UserData.getProductInfoFromUser();
				product.setProductId(id);
				String msg = operation.updateProduct(product);
				System.out.println(msg);
				break;
			}
			case 5:{
				List<Product> list = operation.getAllProducts();
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.println(product);
					}
				}else {
					System.out.println("No record found");
				}
				break;
			}
			case 6:{
				List<Product> list = operation.getAllProductsByOrder();
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.println(product);
					}
				}else {
					System.out.println("No record found");
				}
				break;
			}
			case 7:{
				List<Product> list = operation.getLimitedProducts();
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.println(product);
					}
				}else {
					System.out.println("No record found");
				}
				break;
			}
			case 8:{
				List<Product> list = operation.getLimitedProductsInOrder();
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.println(product);
					}
				}else {
					System.out.println("No record found");
				}
				break;
			}

			case 9:{
				System.out.println("Enter the product name :");
				String name = scanner.next();
				List<Product> list = operation.getProductByName(name);
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.println(product);
					}
				}else {
					System.out.println("No record found");
				}
				break;
			}
			
			case 10:{
				
				List<Product> list = operation.getProductByIds();
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.println(product);
					}
				}else {
					System.out.println("No record found");
				}
				break;
			}
			
			case 11:{
				
				List<Product> list = operation.getProductBetweenIds();
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.println(product);
					}
				}else {
					System.out.println("No record found");
				}
				break;
			}
			
			case 12:{
				
				long count = operation.productCount();
				System.out.println(count);
				break;
			}
			
			
			case 13:{
				
				double count = operation.minimumPriceProduct();
				System.out.println(count);
				break;
			}
			
			case 14:{
				
				double count = operation.maximumPriceProduct();
				System.out.println(count);
				break;
			}

			case 15:{
				List<Product> list = operation.getProductByMfgOrQty();
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.println(product);
					}
				}else {
					System.out.println("No record found");
				}
				break;
			}
			// ----- Hibernate Query ------
			case 16:{
				List<Product> list = operation.queryEx1();
				
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.println(product);
					}
				}else {
					System.out.println("No record found");
				}

				break;
			}

			
			case 17:{
				List<Object[]> list = operation.queryEx2();
				
				if(!list.isEmpty()) {
					for(Object[] object : list) {
						System.out.print(object[0]);
						System.out.print(object[1]);
						System.out.println(object[2]);
					}
				}else {
					System.out.println("No record found");
				}

				break;
			}

			case 18:{
				List<Product> list = operation.queryEx3();
				
				if(!list.isEmpty()) {
					for(Product product : list) {
						System.out.print(product);					}
				}else {
					System.out.println("No record found");
				}

				break;
			}

			
			default :
				System.out.println("Invalid Choise");
				break;
			}
		}while(wantToContinue);
		System.out.println("App Terminated");
	}

}
