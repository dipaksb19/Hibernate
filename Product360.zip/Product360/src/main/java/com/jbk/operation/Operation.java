package com.jbk.operation;

import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.jbk.config.HibernateConfig;
import com.jbk.entity.Product;

public class Operation {
	

	SessionFactory sessionFactory = HibernateConfig.getSessionFactory();
	public String addProduct(Product product) {
		
		try {
			Session session = sessionFactory.openSession();
			
			Product dbProduct = session.get(Product.class, product.getProductId());
			
			if(dbProduct == null) {
			
			session.save(product);
			session.beginTransaction().commit();
			
			return "Added successfully";
			}else {
				return "Product already exists";
			}

			
		}catch(Exception e){
			return "Something went wrong";
		}
	}
	
	public String deleteProduct(int productId) {
		Session session = sessionFactory.openSession();
		try {
			Product dbProduct = session.get(Product.class, productId);
			if(dbProduct != null) {
				session.delete(dbProduct);
				session.beginTransaction().commit();
				return "Product Deleted";
			}else {
				return "Product Not Exists to Delete";
			}
//			Product product = new Product();
//			product.setProductId(productId);
			
		}catch(Exception e){
			return "Something went wrong";
		}
		
	}

	public Object getProductById(int productId) {
		Session session = sessionFactory.openSession();
		try {
			Product dbProduct = session.get(Product.class, productId);
			if(dbProduct != null) {
				return dbProduct;
			}else {
				return "Product Not Exists";
			}
			
		}catch(Exception e){
			return "Something went wrong";
		}
	}
	
	public String updateProduct(Product product){
	
		try {
			Session session = sessionFactory.openSession();
			
			Product dbProduct = session.get(Product.class, product.getProductId());
			
			if(dbProduct != null) {
			session.evict(dbProduct);
			session.update(product);
			session.beginTransaction().commit();
			return "Updated successfully";
			}else {
				return "Product does not exists";
			}

			
		}catch(Exception e){
			e.printStackTrace();
			return "Something went wrong";
		}
	}
	
	// ------Hibernate Criteria-------
	
	public List<Product> getAllProducts() {
		Session session = sessionFactory.openSession();
		//session.byMultipleIds(Product.class).multiLoad(1,2,3);
		List<Product> list = null;
		try {
			Criteria criteria = session.createCriteria(Product.class);
			list = criteria.list();
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	public List<Product> getAllProductsByOrder() {
		Session session = sessionFactory.openSession();
		//session.byMultipleIds(Product.class).multiLoad(1,2,3);
		List<Product> list = null;
		try {
			Criteria criteria = session.createCriteria(Product.class);
			criteria.addOrder(Order.asc("productName"));
			list = criteria.list();
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	public List<Product> getLimitedProducts() {
		Session session = sessionFactory.openSession();
		//session.byMultipleIds(Product.class).multiLoad(1,2,3);
		List<Product> list = null;
		try {
			Criteria criteria = session.createCriteria(Product.class);
			criteria.setMaxResults(2);
			list = criteria.list();
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public List<Product> getLimitedProductsInOrder() {
		Session session = sessionFactory.openSession();
		//session.byMultipleIds(Product.class).multiLoad(1,2,3);
		List<Product> list = null;
		try {
			Criteria criteria = session.createCriteria(Product.class);
			criteria.setMaxResults(2);
			criteria.addOrder(Order.asc("productName"));
			list = criteria.list();
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//---------Hibernate Restrictions--------
	
	public List<Product> getProductByName(String name) {
		Session session = sessionFactory.openSession();
		//session.byMultipleIds(Product.class).multiLoad(1,2,3);
		List<Product> list = null;
		try {
			Criteria criteria = session.createCriteria(Product.class);
			criteria.add(Restrictions.eq("productName",name));
			list = criteria.list();
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public List<Product> getProductByIds() {
		Session session = sessionFactory.openSession();
		//session.byMultipleIds(Product.class).multiLoad(1,2,3);
		List<Product> list = null;
		try {
			Criteria criteria = session.createCriteria(Product.class);
			criteria.add(Restrictions.in("productId",1,3));
			list = criteria.list();
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	public List<Product> getProductBetweenIds() {
		Session session = sessionFactory.openSession();
		//session.byMultipleIds(Product.class).multiLoad(1,2,3);
		List<Product> list = null;
		try {
			Criteria criteria = session.createCriteria(Product.class);
			criteria.add(Restrictions.between("productId",1,3));
			list = criteria.list();
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	// -----------Hibernate Projection----------
	// total count
	public long productCount() {
		Session session = sessionFactory.openSession();
		long count = 0;
		try {
			Criteria criteria = session.createCriteria(Product.class);
			criteria.setProjection(Projections.rowCount());
			
			List<Long> list = criteria.list();
			
			if(!list.isEmpty()) {
				count = list.get(0);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	
	// to get minimum price product
	public double minimumPriceProduct() {
		Session session = sessionFactory.openSession();
		double count = 0;
		try {
			Criteria criteria = session.createCriteria(Product.class);
			criteria.setProjection(Projections.min("productPrice"));
			
			List<Double> list = criteria.list();
			
			if(!list.isEmpty()) {
				count = list.get(0);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	
	// to get maximum price product
		public double maximumPriceProduct() {
			Session session = sessionFactory.openSession();
			double count = 0;
			try {
				Criteria criteria = session.createCriteria(Product.class);
				criteria.setProjection(Projections.max("productPrice"));
				
				List<Double> list = criteria.list();
				
				if(!list.isEmpty()) {
					count = list.get(0);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			return count;
		}
		
		// ----Hibernate Multiple Restrictions-----
		// using (Restrictions)
		// get the products having mfg date (2020-08-08) or Qty 100
		
		public List<Product> getProductByMfgOrQty() {
			Session session = sessionFactory.openSession();
			
			List<Product> list = null;
			try {
				Criteria criteria = session.createCriteria(Product.class);

				SimpleExpression mfg = Restrictions.eq("mfgDate", "2024-06-06");
				SimpleExpression qty = Restrictions.eq("productQty", 1500);
				criteria.add(Restrictions.or(mfg,qty));
				
				list = criteria.list();
				return list;
			}catch(Exception e) {
				e.printStackTrace();
			}
			return list;
		}
		
		//-------Hibernate Query-----
		//HQL to select all products 

		public List<Product> queryEx1() {
			Session session = sessionFactory.openSession();
			
			List<Product> list = null;
			try {
				String hql = "FROM Product";
				Query query = session.createQuery(hql);
				list = query.list();
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return list;
		}
		
		//HQL to select specific columns(Retrives specific column)
		
		public List<Object[]> queryEx2() {
			Session session = sessionFactory.openSession();
			
			List<Object[]> list = null;
			try {
				String hql = "select productId, productName, productPrice from Product";
				Query query = session.createQuery(hql);
				list = query.list();
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return list;
		}

		// by passing parameter in Query to find specific data
		
		public List<Product> queryEx3() {
			Session session = sessionFactory.openSession();
			List<Product> list = null;
			
			try {
				String hql = "from Product where productname =:pname";
				Query query = session.createQuery(hql);
				query.setString("pname", "pen");
				list = query.list();
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			return list;
		}

		

}










